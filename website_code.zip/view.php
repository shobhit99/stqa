<html>
<head>
<title>Medical Records | View Details</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery-3.3.1.slim.min.js"></script>
<script src="js/popper.min.js"></script>
</head>
<body>
<div class="container h-100">
<div class="row h-100 justify-content-center align-items-center">
    <div class="col-sm-6 col-md-5">
        <h3 class="text-center">View Patient Details</h3><br>
        <form method="POST" action="view.php">
            <div class="form-group">
                <input type="text" class="form-control" name="email" placeholder="Email">
            </div>
            <div class="form-group">
                <input type="password" class="form-control" name="password" placeholder="Password">
            </div>
            <div class="form-group">
                <button class="btn btn-primary" name="view">View Details</button> 
            </div>
            <span class="text-muted"> Not yet Registered ? Reigster</span><a href="index.php"> here</a>
        </form>
        <div>
            <?php
            include 'dbconnect.php';
               if(isset($_POST['view'])){
                   if(!empty($_POST['email'])&&!empty($_POST['password']))
                   {
                    $email      = $_POST['email'];
                    $password   = $_POST['password'];
                    $password = md5($password);

                    $query = "SELECT * FROM patients WHERE email='$email' AND password='$password'";
                    if($rows = mysqli_query($conn, $query)){
                        if(mysqli_num_rows($rows) == 0){
                            echo "<span class='text-danger' name='msg'>Invalid Email or Password</span>";
                        }else{
                            $query = "SELECT * FROM patients WHERE email='$email'";
                            $data  = mysqli_fetch_assoc(mysqli_query($conn, $query));
                            echo "<span class='text-success' name='msg'>Found one matching record</span>";
                            echo "<h4> Name: <span class='text-muted'>".$data['firstname']." ".$data['lastname']."</span></h4>";
                            echo "<h4> Email: <span class='text-muted'>".$data['email']."</span></h4>";
                            echo "<h4> Mobile No: <span class='text-muted'>".$data['mobile_no']."</span></h4>";
                            echo "<h4> Address: <span class='text-muted'>".$data['address']."</span></h4>";
                            echo "<h4> Gender: <span class='text-muted'>".$data['gender']."</span></h4>";
                            echo "<h4> Blood Group: <span class='text-muted'>".$data['blood_group']."</span></h4>";
                            echo "<h4> DOB: <span class='text-muted'>".$data['dob']."</span></h4>";
                        }
                    }else{
                        echo "<span class='text-danger' name='msg'>Query failed</span>";
                    }
                   }
                   else{
                       echo "<span class='text-danger' name='msg'>All fields are required</span>";
                   }
               }
            ?>
        </div>
    </div>
</div>
</div>
</body>
</html>