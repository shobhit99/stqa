<html>
<head>
<title>Medical Records | Register</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery-3.3.1.slim.min.js"></script>
<script src="js/popper.min.js"></script>
</head>
<body>
<div class="container h-100">
<div class="row h-100 justify-content-center align-items-center">
    <div class="col-sm-6 col-md-4">
        <h3 class="text-center">Patient Registration</h3><br>
        <form method="POST" action="index.php">
            <div class="form-group">
                <div class="input-group">
                <input type="text" class="form-control" name="firstname" placeholder="First Name">
                <input type="text" class="form-control" name="lastname" placeholder="Last Name">
                </div>
            </div>
            <div class="form-group">
                <input type="text" class="form-control" name="email" placeholder="Email">
            </div>
            <div class="form-group">
                <input type="text" class="form-control" name="mobileno" placeholder="Mobile No">
            </div>
            <div class="form-group">
                <input type="text" class="form-control" name="address" placeholder="Address">
            </div>
            <div class="form-group">
                <input type="password" class="form-control" name="password" placeholder="Password">
            </div>
            <div class="form-group">
                <input type="password" class="form-control" name="repeat_password" placeholder="Repeat Password">
            </div>
            <div class="form-group">
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Gender</span>
                    </div>
                    <select class="custom-select" name="gender">
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Blood Group</span>
                    </div>
                    <select class="custom-select" name="blood_group">
                        <option value="A+">A+</option>
                        <option value="A-">A-</option>
                        <option value="B+">B+</option>
                        <option value="B-">B-</option>
                        <option value="O+">O+</option>
                        <option value="O-">O-</option>
                        <option value="AB+">AB+</option>
                        <option value="AB-">AB-</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <div class="input-group">
                    <span class="input-group-text">DOB</span>
                    <input type="text" class="form-control" name="dob" placeholder="yyyy/mm/dd">
                </div>
            </div>
            <div class="form-group">
                <button class="btn btn-success" name="register">Register</button>
                
            </div>
            <span class="text-muted"> Already Registered ? </span><a href="view.php">View Details</a>
        </form>
        <div name="message">
            <?php
            include 'dbconnect.php';
               if(isset($_POST['register'])){
                   if(!empty($_POST['firstname'])&&!empty($_POST['lastname'])&&!empty($_POST['email'])&&!empty($_POST['mobileno'])&&!empty($_POST['password'])
                   &&!empty($_POST['repeat_password'])&&!empty($_POST['dob'])&&!empty($_POST['address'])
                   ){
                    $firstname  = $_POST['firstname'];
                    $lastname   = $_POST['lastname'];
                    $email      = $_POST['email'];
                    $mobileno   = $_POST['mobileno'];
                    $address    = $_POST['address'];
                    $password   = $_POST['password'];
                    $repassword = $_POST['repeat_password'];
                    $dob        = $_POST['dob'];
                    $gender     = $_POST['gender'];
                    $blood_g    = $_POST['blood_group'];
                    
                    if($password!=$repassword){
                        die("Passwords donot match");
                    }
                    if(!preg_match("/[A-Za-z0-9]+@[A-Za-z0-9]+\.[A-Za-z0-9]{1,10}/",$email)){
                        die("Invalid email address");
                    }
                    if(!preg_match("/[0-9]{10}/",$mobileno)){
                        die("Mobile number should be exactly 10 digits");
                    }
                    if(!preg_match("/.{10,}/",$address)){
                        die("Address length must be greater than 10");
                    }
                    if(!preg_match("/[0-9]{4}\/[0-9]{1,2}\/[0-9]{1,2}/",$dob)){
                        die("Invalid date of birth");
                    }
                    if(strlen($password)<7){
                        die("Password length must be greater than 6");
                    }
                    $password = md5($password);
                    $check_query = "SELECT * FROM patients WHERE email='$email'";
                    if(mysqli_num_rows(mysqli_query($conn, $check_query)) !=0 ){
                        die("Email already registered");
                    }
                    $query = "INSERT INTO patients(firstname, lastname, email, mobile_no, address, password, gender, blood_group, dob) values
                                ('$firstname', '$lastname', '$email', '$mobileno', '$address', '$password', '$gender', '$blood_g', '$dob')";
                    if(mysqli_query($conn, $query)){
                        echo "Patient registered successfully!";
                    }else{
                        echo "Query failed";
                    }
                   }
                   else{
                       echo "All fields are required";
                   }
               }
            ?>
        </div>
    </div>
</div>
</div>
</body>
</html>