<?php
$username = "root";
$password = "";
$database = "medical_records";
$host = "localhost";
$conn = mysqli_connect($host, $username, $password, $database);
if(!$conn){
	die("Failed to Connect to Database");
}
?>